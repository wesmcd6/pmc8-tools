#!/usr/bin/env python3
"""
PMC8 ESP32 Serial Flash Script -- DRAFT

Walks the user through a serial-port ESP32 firmware update using the
proploader.exe (Propeller P1 loader) and esptool. See
SERIAL_FLASH_USER_GUIDE.txt for the full procedure.

User steps are reduced to physical jumper installation/removal. The
Propeller binary loads and the ESP32 flash are all automated:
  - Phase 0: serial probe for OTA feasibility (exits early if OTA works)
  - Phase 1: validate all bundled files (firmware binaries + proploader)
  - Phase 2: user installs boot jumper (opens enclosure)
  - Phase 3: automated -- proploader loads ESP_Loader onto Propeller
  - Phase 4: automated -- esptool flashes factory_WROOM-32.bin to ESP32
  - Phase 5: user removes jumper + closes enclosure, then automated --
             proploader loads normal PMC8 Propeller firmware
  - Phase 6: automated -- queries PMC8 over serial to verify

Requirements:
    pip install pyserial esptool
"""

import sys
import os
import time
import subprocess
import re
import argparse


# ── Dependency auto-install ──────────────────────────────────────────────────

def ensure_package(pkg, import_name=None):
    """Make sure a pip package is installed; offer to install if missing."""
    import_name = import_name or pkg
    try:
        __import__(import_name)
        return
    except ImportError:
        pass
    print(f"{pkg} is required but not installed.")
    answer = input(f"Install {pkg} now? (y/n): ").strip().lower()
    if answer != "y":
        print(f"Cannot continue without {pkg}.")
        sys.exit(1)
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
    except Exception as e:
        print(f"ERROR: pip install {pkg} failed: {e}")
        print(f"Try running manually:  pip install {pkg}")
        sys.exit(1)
    try:
        __import__(import_name)
    except ImportError:
        print(f"ERROR: {pkg} installation did not take effect.")
        sys.exit(1)


ensure_package("pyserial", import_name="serial")
ensure_package("esptool")

import serial
import serial.tools.list_ports


# ── Constants ────────────────────────────────────────────────────────────────

BAUD_RATE = 115200

DEFAULT_ESP_LOADER = os.path.join("firmware", "ESPLoad1.binary")
DEFAULT_FACTORY_FW = os.path.join("firmware", "factory_WROOM-32.bin")
DEFAULT_NORMAL_PROP_FW = os.path.join("firmware", "pmc8_normal_firmware.binary")

PROPLOADER_REL_PATH = os.path.join("tools", "proploader.exe")

# Expected binary size ranges (lower, upper) -- used for sanity checking
PROPELLER_BINARY_RANGE = (1_024, 500_000)      # Propeller P1 program
FACTORY_FW_EXACT = 4 * 1024 * 1024              # Full ESP32 flash image = 4 MB

AT_TIMEOUT = 5
POST_RESTORE_BOOT_WAIT = 15  # seconds to wait for PMC8 to boot after Step 3

# Phase 3 timing: after proploader finishes, how long to let ESP_Loader
# settle before we pulse DTR (to force the ESP32 into bootloader mode),
# then how long to wait after the DTR pulse before esptool connects.
# These defaults can be overridden from the command line for tuning.
DEFAULT_PRE_DTR_WAIT_S = 5
DEFAULT_POST_DTR_WAIT_S = 10

# PMC8 pass-through protocol (used for talking to the ESP32 via the
# Propeller's normal firmware)
PASSTHROUGH_ENTER = "ESPw42!"     # ES command to Propeller: enter pass-through
PASSTHROUGH_EXIT  = "###"          # exit pass-through, return to ES command mode


# ── Helpers ──────────────────────────────────────────────────────────────────

def log(phase, msg):
    print(f"[{phase}] {msg}")


def banner(title):
    print()
    print("=" * 72)
    print("  " + title)
    print("=" * 72)


def prompt_enter(msg):
    """Pause for user to press Enter -- returns when they do."""
    print()
    input(f">>> {msg}\n    (press Enter to continue)")
    print()


def list_com_ports():
    """Return a list of (port_name, description) for visible COM ports."""
    return [(p.device, p.description) for p in serial.tools.list_ports.comports()]


def pick_com_port(default_port=None):
    """Prompt user to pick a COM port. If default given and valid, accept it."""
    ports = list_com_ports()
    if default_port:
        return default_port
    if not ports:
        print("No COM ports found. Connect the PMC8 via USB and retry.")
        sys.exit(1)
    print("\nAvailable COM ports:")
    for i, (dev, desc) in enumerate(ports, 1):
        print(f"  {i}. {dev} -- {desc}")
    choice = input("Select a port (number or name, e.g. COM3): ").strip()
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(ports):
            return ports[idx][0]
    # Accept raw name
    return choice or ports[0][0]


def validate_file(path, description, exact_size=None, size_range=None):
    """Check a file exists and (optionally) has the expected size."""
    if not os.path.isfile(path):
        log("Phase 1", f"ERROR: {description} not found: {path}")
        return False
    size = os.path.getsize(path)
    if exact_size is not None and size != exact_size:
        log("Phase 1",
            f"ERROR: {description} size is {size:,} bytes; expected {exact_size:,}. "
            f"Wrong file?")
        return False
    if size_range is not None:
        lo, hi = size_range
        if not (lo <= size <= hi):
            log("Phase 1",
                f"ERROR: {description} size is {size:,} bytes; expected "
                f"{lo:,}-{hi:,} range. Wrong file?")
            return False
    log("Phase 1", f"OK: {description} -- {path} ({size:,} bytes)")
    return True


def parse_esp_version(data):
    """Extract (version, module) from any ESP-AT firmware info blob.

    Accepts bytes or str. Returns (version, module) or (None, None).

    Prefers the "Bin version:" line (which reflects CONFIG_APP_PROJECT_VER)
    over other version-looking strings that appear earlier in AT+GMR
    output (like "AT version:" or "SDK version:")."""
    if isinstance(data, str):
        data = data.encode("ascii", errors="replace")

    # Preferred: pull from the "Bin version:..." line in AT+GMR output.
    # Format at runtime is:
    #   Bin version:ES4.2.0(WROOM-32)
    #   Bin version:4.2.0(WROOM-32)
    # But the raw binary also contains the printf template "Bin version:%s(%s)".
    # We have to validate the captured text looks like an actual version,
    # otherwise %s slips through and we report version='%s'.
    bin_match = re.search(rb'Bin version:\s*([^\s(]+)(?:\(([^)]+)\))?', data)
    if bin_match:
        version_raw = bin_match.group(1).decode("ascii", errors="replace").strip()
        if re.match(r'^[A-Za-z]*\d+\.\d+\.\d+', version_raw):
            module = None
            if bin_match.group(2):
                mod_raw = bin_match.group(2).decode("ascii", errors="replace").strip()
                # Only accept module strings that look plausible (have a digit).
                if re.search(r'\d', mod_raw):
                    module = mod_raw
            if module is None:
                mod_match = re.search(rb'(WROOM-\d+|WROVER-\d+|MINI-\d+|PICO-\w+)', data)
                module = mod_match.group(1).decode("ascii") if mod_match else None
            return (version_raw, module)
        # Bin version: line matched but the captured token was a format
        # placeholder (e.g. '%s') -- fall through to the generic scan.

    # Fallback: scan for any version-shaped token. Used when reading the
    # factory binary directly (Bin version: is a format template there).
    ver_match = re.search(rb'(\w*\d+\.\d+\.\d+)', data)
    mod_match = re.search(rb'(WROOM-\d+|WROVER-\d+|MINI-\d+|PICO-\w+)', data)
    version = ver_match.group(1).decode("ascii") if ver_match else None
    module = mod_match.group(1).decode("ascii") if mod_match else None
    return (version, module)


def normalize_version(v):
    """Strip common prefixes so 'ES4.2.0' and '4.2.0' compare equal."""
    if not v:
        return None
    v = v.strip()
    # Strip a leading alpha prefix like 'ES' or 'v'
    m = re.match(r'^[A-Za-z]+(\d.*)$', v)
    if m:
        return m.group(1)
    return v


def parse_propeller_version(esgv_response):
    """Parse a PMC8 Propeller firmware version from an ESGv! response.

    The response text looks like:
        ESGvES20A02.1.8.2.bt Release 2026.03.02!
    Returns the version string (e.g. '20A02.1.8.2') or None."""
    m = re.search(r'(\d{2}[A-Z]\d{2}(?:\.\d+)+)', esgv_response)
    return m.group(1) if m else None


def propeller_version_is_supported(version):
    """Check that a Propeller version string is 20A02.0 or newer. The
    pass-through bridge (ESPw42!) was added in 20A02 so anything earlier
    can't be used for Phase 0 probing or OTA updates."""
    if not version:
        return False
    # Simple lex comparison on the major portion works for current naming.
    return version[:5] >= "20A02"


def scan_esp_firmware_version(fw_path):
    """Scan a factory ESP32 binary for its embedded version string."""
    with open(fw_path, "rb") as f:
        data = f.read(0x200000)  # scan first 2 MB
    return parse_esp_version(data)


def read_esp_version_via_passthrough(port, phase_label="Phase 6"):
    """Open serial, enter pass-through, probe ESP32, read AT+GMR, exit.

    Returns (version, module, raw_gmr_text). Any of version/module may be
    None if the ESP32 didn't respond with a parseable version string.
    raw_gmr_text is the raw AT+GMR response (or an error description)."""
    try:
        ser = open_pmc8_serial(port)
    except Exception as e:
        return None, None, f"[could not open {port}: {e}]"

    try:
        log(phase_label, "Serial port open, settling...")
        time.sleep(2)
        ser.reset_input_buffer()

        log(phase_label, f"Entering pass-through ({PASSTHROUGH_ENTER})...")
        send_es_command(ser, PASSTHROUGH_ENTER)
        time.sleep(2)
        ser.reset_input_buffer()

        log(phase_label, "Probing ESP32 (AT)...")
        ok = False
        for attempt in range(5):
            resp = send_at_command(ser, "AT")
            if "OK" in resp:
                ok = True
                break
            time.sleep(0.5)
        if not ok:
            return None, None, "[no AT response from ESP32]"

        log(phase_label, "Reading firmware version (AT+GMR)...")
        resp = send_at_command(ser, "AT+GMR")
        version, module = parse_esp_version(resp)
        return version, module, resp
    finally:
        try:
            ser.write(PASSTHROUGH_EXIT.encode("ascii"))
            time.sleep(1)
        except Exception:
            pass
        try:
            ser.close()
        except Exception:
            pass


def pulse_propeller_reset(port):
    """Toggle DTR to reset the PMC8 Propeller. Used after ESP_Loader is
    loaded to force ESPLoader to re-initialize and reset the ESP32 via
    its EN pin, putting the ESP32 into bootloader mode (assuming GPIO0
    is held low by the BOOT_OPT jumper).

    The usual DTR/RTS-held-low invariant is broken briefly here. Don't
    call this with the normal PMC8 Propeller firmware running unless a
    reset is actually desired."""
    ser = serial.Serial()
    ser.port = port
    ser.baudrate = BAUD_RATE
    ser.timeout = 1
    ser.dtr = False
    ser.rts = False
    ser.open()
    try:
        ser.dtr = True    # assert -> Propeller held in reset
        time.sleep(0.1)
        ser.dtr = False   # release -> Propeller boots (EEPROM = ESP_Loader)
    finally:
        ser.close()


def run_proploader(port, proploader_exe, binary_path, phase_label):
    """Run proploader.exe to load a Propeller binary to EEPROM and run it.

    proploader_exe is the full path to tools/proploader.exe. binary_path is
    the Propeller .binary file to load. port is the COM port. Streams output
    live. Returns True if exit code 0, False otherwise."""
    cmd = [str(proploader_exe), "-p", port, "-e", "-r", str(binary_path)]
    log(phase_label, "Running proploader:")
    log(phase_label, "  " + " ".join(cmd))
    print("-" * 72)

    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        bufsize=1, universal_newlines=True,
    )
    all_output = []
    try:
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            all_output.append(line)
    finally:
        proc.wait()
    print("-" * 72)

    if proc.returncode != 0:
        log(phase_label, f"proploader exited with code {proc.returncode}")
        return False
    log(phase_label, "proploader completed successfully.")
    return True


def run_esptool_flash(port, fw_path):
    """Run esptool write_flash, streaming output to the user.

    Returns True on success (exit code 0 AND 'Hash of data verified' seen)."""
    cmd = [
        sys.executable, "-m", "esptool",
        "--chip", "esp32",
        "--port", port,
        "--baud", str(BAUD_RATE),
        "--before", "no-reset",
        "--after", "no-reset",
        "write-flash", "0x0", fw_path,
    ]
    log("Phase 4", "Running esptool:")
    log("Phase 4", "  " + " ".join(cmd))
    print("-" * 72)

    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        bufsize=1, universal_newlines=True,
    )
    all_output = []
    try:
        for line in proc.stdout:
            sys.stdout.write(line)
            sys.stdout.flush()
            all_output.append(line)
    finally:
        proc.wait()
    print("-" * 72)

    combined = "".join(all_output)
    if proc.returncode != 0:
        log("Phase 4", f"esptool exited with code {proc.returncode}")
        return False
    if "Hash of data verified" not in combined:
        log("Phase 4", "esptool finished but 'Hash of data verified' was NOT seen.")
        return False
    log("Phase 4", "esptool completed successfully (hash verified).")
    return True


def open_pmc8_serial(port, timeout=AT_TIMEOUT):
    """Open the PMC8 serial port with DTR/RTS held LOW so opening the port
    does not reset the Propeller (which would reset the whole PMC8)."""
    ser = serial.Serial()
    ser.port = port
    ser.baudrate = BAUD_RATE
    ser.timeout = timeout
    ser.dtr = False
    ser.rts = False
    ser.open()
    ser.reset_input_buffer()
    return ser


def send_chars_paced(ser, text):
    """Send characters one at a time with a 5 ms inter-character delay.
    Required for Propeller pass-through -- bulk writes can overflow its
    receive buffer and corrupt AT commands to the ESP32."""
    for ch in text:
        ser.write(ch.encode("ascii"))
        time.sleep(0.005)


def read_until(ser, expect=None, timeout=AT_TIMEOUT):
    """Read serial until `expect` substring is found or timeout."""
    ser.timeout = timeout
    buf = b""
    deadline = time.time() + timeout
    while time.time() < deadline:
        chunk = ser.read(ser.in_waiting or 1)
        if chunk:
            buf += chunk
            text = buf.decode("ascii", errors="replace")
            if expect and expect in text:
                return text
        else:
            time.sleep(0.05)
    return buf.decode("ascii", errors="replace")


def send_es_command(ser, cmd, timeout=AT_TIMEOUT):
    """Send an ES command (terminated by '!') to the Propeller."""
    send_chars_paced(ser, cmd)
    return read_until(ser, expect="!", timeout=timeout)


def send_at_command(ser, cmd, timeout=AT_TIMEOUT, expect="OK"):
    """Send an AT command through the Propeller pass-through.
    Commands are terminated with '@' (the Propeller translates to CR/LF
    before forwarding to the ESP32)."""
    send_chars_paced(ser, cmd + "@")
    return read_until(ser, expect=expect, timeout=timeout)


def query_pmc8(port, cmd, timeout=AT_TIMEOUT):
    """Send an ES command directly to the Propeller (no pass-through)
    and return (response_text, error_message). DTR/RTS held low."""
    try:
        ser = open_pmc8_serial(port, timeout=timeout)
    except serial.SerialException as e:
        return None, f"could not open {port}: {e}"
    try:
        resp = send_es_command(ser, cmd, timeout=timeout)
        return resp, None
    finally:
        ser.close()


def check_ota_feasibility(port):
    """Check PMC8 Propeller firmware version, then enter pass-through mode
    and probe for AT+USEROTA support. Also captures the current ESP32
    firmware version for before/after comparison.

    Returns a tuple (status, version, module) where status is one of:
      'supported'          -- AT+USEROTA recognized; OTA should work
      'not_supported'      -- command rejected; firmware is too old for OTA
      'no_response'        -- Propeller is fine but ESP32 isn't responding
                              (firmware missing / dead -- serial flash needed)
      'propeller_too_old'  -- PMC8 Propeller firmware predates pass-through
                              support (must be 20A02.0 or newer). Caller
                              should abort and tell the user to upgrade
                              the Propeller first.
      'error'              -- couldn't even open the port / other fatal issue
    version/module are populated from AT+GMR if the ESP32 responded,
    otherwise None.
    """
    old_version, old_module = None, None
    try:
        ser = open_pmc8_serial(port)
    except Exception as e:
        log("Phase 0", f"ERROR: could not open {port}: {e}")
        return "error", old_version, old_module

    try:
        log("Phase 0", "Serial port open (DTR/RTS held low).")
        log("Phase 0", "Letting port settle for 3s...")
        time.sleep(3)
        ser.reset_input_buffer()

        # First: read PMC8 Propeller version via ESGv!. The pass-through
        # bridge (ESPw42!) and the OTA feature both require Propeller
        # firmware 20A02.0 or newer. If the mount is running older firmware,
        # we can't probe at all -- the user has to upgrade the Propeller
        # before either OTA or serial-flash will work.
        log("Phase 0", "Checking PMC8 Propeller firmware version (ESGv!)...")
        resp = send_es_command(ser, "ESGv!")
        log("Phase 0", f"  ESGv! response: {resp.strip()!r}")
        prop_version = parse_propeller_version(resp)
        if prop_version:
            log("Phase 0", f"  Propeller firmware: {prop_version}")
        else:
            log("Phase 0", "  Could not parse a Propeller version from the response.")
        if not propeller_version_is_supported(prop_version):
            log("Phase 0", "  Propeller firmware is too old (or unreadable).")
            return "propeller_too_old", old_version, old_module

        log("Phase 0", f"Entering pass-through mode ({PASSTHROUGH_ENTER})...")
        resp = send_es_command(ser, PASSTHROUGH_ENTER)
        log("Phase 0", f"Propeller response: {resp.strip()!r}")
        time.sleep(2)
        ser.reset_input_buffer()

        log("Phase 0", "Probing ESP32 (AT)...")
        ok = False
        for attempt in range(3):
            resp = send_at_command(ser, "AT")
            log("Phase 0", f"  attempt {attempt + 1}: {resp.strip()!r}")
            if "OK" in resp:
                ok = True
                break
        if not ok:
            log("Phase 0", "ESP32 is NOT responding to AT commands.")
            log("Phase 0", "Its firmware is likely missing or dead -- OTA cannot be used.")
            return "no_response", old_version, old_module

        log("Phase 0", "ESP32 is responding. Reading firmware version (AT+GMR)...")
        resp = send_at_command(ser, "AT+GMR")
        for line in resp.splitlines():
            line = line.strip()
            if line and line not in ("OK", ""):
                log("Phase 0", f"  GMR: {line}")
        old_version, old_module = parse_esp_version(resp)
        if old_version:
            label = f"{old_version}({old_module})" if old_module else old_version
            log("Phase 0", f"Captured current ESP32 version for later comparison: {label}")
        ser.reset_input_buffer()

        # Prime with another AT@ before the real probe -- the first AT+USEROTA
        # attempt can return a stale ERROR from buffer residue.
        log("Phase 0", "Priming with plain AT before AT+USEROTA probe...")
        for attempt in range(3):
            resp = send_at_command(ser, "AT")
            log("Phase 0", f"  AT attempt {attempt + 1}: {resp.strip()!r}")
            if "OK" in resp:
                break
        ser.reset_input_buffer()

        # The only reliable way to probe AT+USEROTA support is to actually
        # start an OTA (the =? test form isn't implemented). We send
        # AT+USEROTA=<length> with a bogus URL length; a supported firmware
        # replies with '>' asking for the URL bytes. We then satisfy the
        # byte count with a deliberately-unreachable URL so the OTA attempt
        # fails fast and the ESP32 returns to idle.
        probe_url = "http://0.0.0.0/x.bin"  # unreachable; 20 chars
        probe_len = len(probe_url)

        log("Phase 0", f"Probing AT+USEROTA support (sending AT+USEROTA={probe_len})...")
        got_prompt = False
        for attempt in range(3):
            resp = send_at_command(ser, f"AT+USEROTA={probe_len}",
                                   timeout=AT_TIMEOUT, expect=">")
            log("Phase 0", f"  AT+USEROTA={probe_len} attempt {attempt + 1}: "
                          f"{resp.strip()!r}")
            if ">" in resp:
                got_prompt = True
                break
            if "ERROR" in resp and attempt < 2:
                log("Phase 0", "  Got ERROR -- sending AT@ to clear, retrying...")
                send_at_command(ser, "AT")
                ser.reset_input_buffer()

        if not got_prompt:
            # All attempts got ERROR (or no '>') -- command is genuinely absent
            return "not_supported", old_version, old_module

        # Got '>' -- command IS supported. Satisfy the byte count with the
        # unreachable URL so the OTA aborts cleanly on HTTP failure.
        log("Phase 0", f"Got '>' prompt -- AT+USEROTA is supported.")
        log("Phase 0", f"Sending bogus URL to abort probe cleanly: {probe_url}")
        send_chars_paced(ser, probe_url)
        # Give the ESP32 a few seconds to try the HTTP fetch, fail, and
        # return to idle state.
        time.sleep(3)
        ser.reset_input_buffer()
        # Verify the ESP32 is back to responsive idle.
        for _ in range(3):
            resp = send_at_command(ser, "AT", timeout=3)
            if "OK" in resp:
                break
            time.sleep(1)
        return "supported", old_version, old_module
    finally:
        try:
            log("Phase 0", f"Exiting pass-through mode ({PASSTHROUGH_EXIT})...")
            ser.write(PASSTHROUGH_EXIT.encode("ascii"))
            time.sleep(1)
        except Exception:
            pass
        try:
            ser.close()
        except Exception:
            pass


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    banner("PMC8 ESP32 Serial Firmware Update")
    print()
    print("This script walks you through re-flashing the ESP32 firmware on")
    print("your PMC8 mount controller using proploader (for the Propeller)")
    print("and esptool (for the ESP32). It is the FALLBACK path -- use it")
    print("only when OTA update isn't possible.")
    print()
    print("=" * 72)
    print("  OTA update is MUCH simpler. Try it first.")
    print("=" * 72)
    print()
    print("OTA update (ota_update_v2.py, esp32-ota distribution) is much")
    print("simpler than serial flash -- no opening the enclosure, no hex")
    print("wrench, no jumper, no risk to the Wi-Fi antenna cable.")
    print()

    parser = argparse.ArgumentParser(description="PMC8 ESP32 Serial Firmware Update")
    parser.add_argument("--port", help="COM port (e.g., COM3)")
    parser.add_argument("--esp-loader", default=DEFAULT_ESP_LOADER,
                        help=f"ESP_Loader Propeller binary (default: {DEFAULT_ESP_LOADER})")
    parser.add_argument("--factory-fw", default=DEFAULT_FACTORY_FW,
                        help=f"ESP32 factory firmware (default: {DEFAULT_FACTORY_FW})")
    parser.add_argument("--normal-prop-fw", default=DEFAULT_NORMAL_PROP_FW,
                        help=f"Normal PMC8 Propeller firmware (default: {DEFAULT_NORMAL_PROP_FW})")
    parser.add_argument("--skip-verify", action="store_true",
                        help="Skip the Phase 6 post-flash serial verification")
    parser.add_argument("--skip-ota-check", action="store_true",
                        help="Skip the Phase 0 OTA feasibility probe (you've already tried OTA)")
    parser.add_argument("--pre-dtr-wait", type=int, default=DEFAULT_PRE_DTR_WAIT_S,
                        help=f"Seconds to wait after ESP_Loader load before "
                             f"pulsing DTR (default: {DEFAULT_PRE_DTR_WAIT_S})")
    parser.add_argument("--post-dtr-wait", type=int, default=DEFAULT_POST_DTR_WAIT_S,
                        help=f"Seconds to wait after the DTR pulse before "
                             f"running esptool (default: {DEFAULT_POST_DTR_WAIT_S})")
    args = parser.parse_args()

    # State that may be populated by Phase 0 and consumed later
    port = None
    old_esp_version = None
    old_esp_module = None

    # ── Phase 0: OTA feasibility check ───────────────────────────────────
    if not args.skip_ota_check:
        banner("Phase 0 -- Check whether OTA can be used instead")
        print()
        print("This script can connect to your mount via serial RIGHT NOW and")
        print("check whether OTA would work. If yes, you can abort this script")
        print("and run ota_update_v2.py -- much simpler.")
        print()
        print("The check needs:")
        print("  - USB cable connecting PC to PMC8")
        print("  - PMC8 powered on and fully booted (wait 15 seconds after")
        print("    power-on)")
        print("  - No other software using the COM port")
        print("  - The mount running its NORMAL firmware (not ESP_Loader --")
        print("    if you've already started the serial procedure, the")
        print("    Propeller is running ESP_Loader and this check won't work)")
        print()
        answer = input("Run the OTA feasibility check? (y/n, recommended=y): "
                       ).strip().lower()
        if answer == "y":
            print()
            print("Connect the PMC8 via USB and power it on. Wait 15 seconds")
            print("after power-on for the mount to fully boot.")
            prompt_enter("When the PMC8 is powered and booted, continue...")

            port = pick_com_port(args.port)
            log("Phase 0", f"Using COM port: {port}")

            # The probe loop: if the Propeller firmware is too old, we
            # offer to load the current one (bundled in this distribution)
            # and re-probe. Only offered once -- if after the update the
            # probe still comes back "too old", we give up.
            propeller_update_offered = False
            while True:
                status, old_esp_version, old_esp_module = check_ota_feasibility(port)
                if status == "propeller_too_old" and not propeller_update_offered:
                    propeller_update_offered = True
                    print()
                    print("The PMC8 Propeller firmware is older than 20A02.0 and")
                    print("doesn't support the pass-through bridge needed by both OTA")
                    print("and serial-flash. (Versions 20A01.x should be replaced.)")
                    print()
                    print("This script can load the current Propeller firmware now,")
                    print("bundled in this distribution, then re-probe -- or you can")
                    print("exit and do it yourself via UFCT.")
                    print()
                    ans = input("Load the current Propeller firmware now? "
                                "(y/n): ").strip().lower()
                    if ans == "y":
                        script_dir = os.path.dirname(os.path.abspath(__file__))
                        prop_fw_update = os.path.join(script_dir, args.normal_prop_fw)
                        proploader_update = os.path.join(script_dir, PROPLOADER_REL_PATH)
                        if not os.path.isfile(prop_fw_update):
                            log("Phase 0", f"ERROR: {prop_fw_update} not found.")
                            sys.exit(1)
                        if not os.path.isfile(proploader_update):
                            log("Phase 0", f"ERROR: {proploader_update} not found.")
                            sys.exit(1)
                        print()
                        log("Phase 0",
                            f"Loading current Propeller firmware: "
                            f"{os.path.basename(prop_fw_update)}")
                        ok = run_proploader(port, proploader_update,
                                            prop_fw_update, "Phase 0")
                        if not ok:
                            log("Phase 0", "Propeller firmware load FAILED. Aborting.")
                            sys.exit(1)
                        log("Phase 0", "Load complete. Waiting 15 s for mount to boot...")
                        time.sleep(15)
                        log("Phase 0", "Re-running feasibility probe with the new firmware...")
                        continue  # loop and re-probe
                break  # any other status (or already offered) -> stop looping

            print()
            if status == "supported":
                banner("OTA IS SUPPORTED")
                print()
                print("The ESP32 responded to AT+USEROTA -- OTA will work.")
                print("Strongly recommended: abort this script, run:")
                print("    python ota_update_v2.py")
                print("from the esp32-ota distribution. It's much simpler.")
                print()
                ans = input("Abort this script and run OTA instead? (y/n, "
                            "recommended=y): ").strip().lower()
                if ans == "y":
                    print("Exiting. Run ota_update_v2.py.")
                    sys.exit(0)
                print("OK, continuing with serial flash at user request.")
            elif status == "not_supported":
                banner("OTA NOT SUPPORTED -- SERIAL FLASH IS REQUIRED")
                print()
                print("The ESP32 firmware does not recognize AT+USEROTA.")
                print("Serial flash is the correct path. Continuing...")
            elif status == "no_response":
                banner("ESP32 IS NOT RESPONDING -- SERIAL FLASH IS REQUIRED")
                print()
                print("The Propeller is responding, but the ESP32 isn't replying")
                print("to AT commands through the pass-through bridge. The ESP32")
                print("firmware may be missing or corrupted. Serial flash is the")
                print("correct path. Continuing...")
            elif status == "propeller_too_old":
                banner("PMC8 PROPELLER FIRMWARE IS TOO OLD -- ABORTING")
                print()
                print("You declined the in-script Propeller firmware update (or it")
                print("didn't take effect). Before re-running this script, use UFCT")
                print("to load PMC8 Propeller firmware 20A02.0 or newer (any 20A01.x")
                print("version is old and should be replaced).")
                print()
                print("(If you believe the Propeller is fine and this is a false")
                print(" positive, re-run with --skip-ota-check to bypass Phase 0.)")
                sys.exit(1)
            else:
                banner("OTA CHECK FAILED")
                print()
                print("The feasibility check couldn't complete -- see messages")
                print("above. Common causes: wrong COM port, another program")
                print("using the port, PMC8 not booted, USB cable fault.")
                print()
                ans = input("Continue with serial flash anyway? (y/n): "
                            ).strip().lower()
                if ans != "y":
                    print("Aborted.")
                    sys.exit(1)
            # Settle a moment before proceeding
            time.sleep(2)
        else:
            print()
            print("OK -- assuming you've already confirmed OTA can't work.")
            print("Proceeding with serial flash.")

    # ── Overview of the procedure ────────────────────────────────────────
    print()
    print("The serial flash procedure:")
    print("  Phase 2 - You install the ESP32 boot jumper (opens enclosure)")
    print("  Phase 3 - This script loads ESP_Loader onto the Propeller")
    print("  Phase 4 - This script flashes the ESP32 firmware")
    print("  Phase 5 - You remove the boot jumper and close the enclosure;")
    print("            this script then restores the normal PMC8 Propeller")
    print("            firmware")
    print("  Phase 6 - This script verifies the mount is responding")
    print()
    print("Full details in SERIAL_FLASH_USER_GUIDE.txt.")
    print("-" * 72)

    script_dir = os.path.dirname(os.path.abspath(__file__))

    # ── Phase 1: Validate ────────────────────────────────────────────────
    banner("Phase 1 -- Pre-flight validation")

    # Re-use the port picked in Phase 0 if it's still valid; otherwise prompt.
    if not port:
        port = pick_com_port(args.port)
    log("Phase 1", f"Using COM port: {port}")
    if old_esp_version:
        baseline = f"{old_esp_version}({old_esp_module})" if old_esp_module else old_esp_version
        log("Phase 1", f"Baseline ESP32 firmware captured in Phase 0: {baseline}")

    esp_loader_path = os.path.join(script_dir, args.esp_loader)
    factory_fw_path = os.path.join(script_dir, args.factory_fw)
    normal_prop_fw_path = os.path.join(script_dir, args.normal_prop_fw)
    proploader_path = os.path.join(script_dir, PROPLOADER_REL_PATH)

    ok = True
    ok &= validate_file(esp_loader_path, "ESP_Loader binary",
                        size_range=PROPELLER_BINARY_RANGE)
    ok &= validate_file(factory_fw_path, "ESP32 factory firmware",
                        exact_size=FACTORY_FW_EXACT)
    ok &= validate_file(normal_prop_fw_path, "Normal PMC8 Propeller firmware",
                        size_range=PROPELLER_BINARY_RANGE)
    if not os.path.isfile(proploader_path):
        log("Phase 1", f"ERROR: proploader.exe not found: {proploader_path}")
        ok = False
    else:
        log("Phase 1", f"OK: proploader.exe -- {proploader_path} "
                       f"({os.path.getsize(proploader_path):,} bytes)")
    if not ok:
        print()
        log("Phase 1", "One or more required files is missing.")
        log("Phase 1", "If you're running this script directly from the git branch,")
        log("Phase 1", "note that the user distribution ships as a zip with all files")
        log("Phase 1", "bundled. The zip contains:")
        log("Phase 1", "    serial_flash.py")
        log("Phase 1", "    SERIAL_FLASH_USER_GUIDE.txt")
        log("Phase 1", "    firmware/factory_WROOM-32.bin")
        log("Phase 1", "    firmware/ESPLoad1.binary")
        log("Phase 1", "    firmware/pmc8_normal_firmware.binary")
        log("Phase 1", "    tools/proploader.exe")
        log("Phase 1", "    tools/proploader-LICENSE.txt")
        log("Phase 1", "")
        log("Phase 1", "Unzip the distribution into a working folder, then re-run this")
        log("Phase 1", "script from inside that folder.")
        sys.exit(1)

    version, module = scan_esp_firmware_version(factory_fw_path)
    if version:
        fw_label = f"{version}({module})" if module else version
        log("Phase 1", f"ESP32 firmware version (from binary): {fw_label}")
    else:
        log("Phase 1", "WARNING: could not detect ESP32 firmware version from binary.")

    # If Phase 0 captured the currently-installed ESP32 version and it
    # matches the binary we're about to flash, the update is apparently
    # not needed. Let the user confirm before proceeding.
    if (old_esp_version and version
            and normalize_version(old_esp_version) == normalize_version(version)):
        print()
        print("  Currently installed ESP32 firmware : "
              f"{old_esp_version}({old_esp_module})"
              if old_esp_module else f"  Currently installed ESP32 firmware : {old_esp_version}")
        print(f"  Binary to be flashed                : {fw_label}")
        print()
        print("The ESP32 is already running the version in the flash binary.")
        print("A serial re-flash is apparently NOT necessary.")
        print()
        ans = input("Proceed with the flash anyway? (y/n): ").strip().lower()
        if ans != "y":
            print("Aborted.")
            sys.exit(0)

    print()
    print("Ready to proceed. Before continuing, make sure:")
    print("  - The PMC8 is connected to this PC via USB.")
    print("  - No other program is using the COM port (ExploreStars, etc).")
    print()
    answer = input("Proceed with the update? (y/n): ").strip().lower()
    if answer != "y":
        print("Aborted.")
        sys.exit(0)

    # ── Phase 2: Hardware prep (user action) ─────────────────────────────
    banner("Phase 2 -- Install the ESP32 Boot Jumper (hardware)")
    print()
    print("Leave the mount powered on and the USB cable connected. You don't")
    print("need to power-cycle between phases.")
    print()
    print("  1. Open the iEXOS-100 circuit board enclosure lid:")
    print("       - Remove the four bolts with a 5/64\" or 2 mm hex wrench.")
    print("       - CAREFUL: the Wi-Fi antenna is adhered to the lid and")
    print("         connected to the circuit board by a short, fragile cable.")
    print("         Lift the lid SLOWLY.")
    print("       - Secure the lid aside with a piece of tape so it doesn't")
    print("         hang on the antenna cable.")
    print()
    print("  2. Locate the BOOT_OPT pin header on the ESP32 Wi-Fi module:")
    print("       - Pair of pins next to the antenna connector.")
    print("       - RIGHT side of the Wi-Fi module (viewed from behind the")
    print("         mount). Silkscreen label: BOOT_OPT.")
    print()
    print("  3. Install a jumper across the two BOOT_OPT pins to short them")
    print("     together.")
    prompt_enter("When the jumper is installed, continue...")

    # ── Phase 3: Load ESP_Loader via proploader (automatic) ──────────────
    banner("Phase 3 -- Load ESP_Loader onto the Propeller (automatic)")
    print()
    log("Phase 3", "Loading ESP_Loader onto the Propeller via proploader.exe...")
    success = run_proploader(port, proploader_path, esp_loader_path, "Phase 3")
    if not success:
        log("Phase 3", "ESP_Loader load FAILED.")
        print()
        print("Things to check:")
        print("  - Is the mount powered on and USB cable connected?")
        print("  - Is the COM port correct and not in use by another program?")
        print("  - Did you install the boot jumper in Phase 2? The jumper is")
        print("    required for the subsequent ESP32 flash (not for this step),")
        print("    but its absence may indicate hardware not fully assembled.")
        print()
        print("Fix the issue, then re-run this script from the start.")
        sys.exit(1)
    log("Phase 3", "ESP_Loader load complete. Mount rebooted automatically.")
    log("Phase 3", "GREEN status light should now be flashing SLOWLY -- ESP_Loader")
    log("Phase 3", "is idle and ready to bridge esptool's traffic to the ESP32.")
    log("Phase 3", f"Waiting {args.pre_dtr_wait} s for ESP_Loader to settle...")
    time.sleep(args.pre_dtr_wait)

    # Some runs have ESPLoader failing to drop the ESP32 into bootloader
    # mode on its first post-load reboot. Pulse DTR to reset the Propeller
    # again: ESPLoader re-initializes from EEPROM and resets the ESP32 via
    # its EN pin. With the BOOT_OPT jumper installed, the ESP32 enters
    # bootloader mode and esptool can connect.
    log("Phase 3", "Pulsing DTR to force a clean ESP_Loader + ESP32 reset...")
    pulse_propeller_reset(port)
    log("Phase 3", f"Waiting {args.post_dtr_wait} s for ESP_Loader to reboot "
                   "and reset the ESP32...")
    time.sleep(args.post_dtr_wait)

    # ── Phase 4: Flash ESP32 via esptool ─────────────────────────────────
    banner("Phase 4 -- Flash the ESP32 (automatic)")
    print()
    print("Watch the green status light on the mount:")
    print("  - Slow flashing before esptool starts  = ESP_Loader idle")
    print("  - Rapid flashing while data is flowing = flash in progress")
    print("  - Returns to slow flashing afterwards  = flash complete")
    print()
    success = run_esptool_flash(port, factory_fw_path)
    if not success:
        log("Phase 4", "ESP32 flash FAILED.")
        print()
        print("Things to check:")
        print("  - Is the BOOT_OPT jumper firmly installed across BOTH pins?")
        print("  - Is the green status light flashing SLOWLY (ESP_Loader idle)?")
        print("  - Is the COM port correct and not in use by another program?")
        print("  - If ESP_Loader may not have reset the ESP32 in time, re-run")
        print(f"    with a longer wait, e.g.:")
        print(f"         python serial_flash.py --post-dtr-wait {args.post_dtr_wait * 2}")
        print(f"    (current --post-dtr-wait={args.post_dtr_wait} s)")
        print()
        print("esptool-specific guidance:")
        print("  https://docs.espressif.com/projects/esptool/en/latest/"
              "troubleshooting.html")
        print()
        print("Fix the issue, then re-run this script from the start. The PMC8")
        print("is safe -- nothing has been written to the Propeller beyond")
        print("ESP_Loader, which you can overwrite in Phase 5.")
        sys.exit(1)

    # ── Phase 5: Restore Propeller firmware (user action) ────────────────
    banner("Phase 5 -- Remove Jumper and Restore Normal Propeller Firmware")
    print()
    print("Leave the mount powered on and the USB cable connected.")
    print()
    print("Hardware steps:")
    print()
    print("  1. Remove the jumper from the BOOT_OPT pins (installed in")
    print("     Phase 2).")
    print()
    print("  2. Close the enclosure lid:")
    print("       - Remove the tape holding the lid aside.")
    print("       - Guide the Wi-Fi antenna cable back into its routing")
    print("         position so it isn't pinched when the lid closes.")
    print("       - Replace the four bolts with the 5/64\" or 2 mm hex wrench.")
    prompt_enter("When the jumper is removed and the enclosure is closed, "
                 "continue...")

    log("Phase 5", "Loading normal PMC8 Propeller firmware via proploader.exe...")
    success = run_proploader(port, proploader_path, normal_prop_fw_path,
                             "Phase 5")
    if not success:
        log("Phase 5", "Propeller firmware load FAILED.")
        print()
        print("The Propeller is still running ESP_Loader. The mount won't")
        print("function normally until the regular firmware is restored.")
        print("Re-run this script; you can use --skip-ota-check to skip")
        print("Phase 0 and skip through to Phase 5.")
        sys.exit(1)
    log("Phase 5", "Normal PMC8 Propeller firmware loaded. Mount rebooted.")

    # ── Phase 6: Verify by reading ESP32 version via pass-through ────────
    banner("Phase 6 -- Verify the Update")

    if args.skip_verify:
        log("Phase 6", "Skipped (--skip-verify).")
        banner("SERIAL FLASH UPDATE COMPLETE")
        print()
        return

    log("Phase 6", f"Waiting {POST_RESTORE_BOOT_WAIT}s for the PMC8 to finish booting...")
    for i in range(POST_RESTORE_BOOT_WAIT, 0, -1):
        print(f"\r  {i}s remaining ", end="", flush=True)
        time.sleep(1)
    print()

    # ── Propeller liveness check (ES commands; NOT pass-through) ─────────
    log("Phase 6", "Querying PMC8 Propeller (ESGp0!)...")
    resp, err = query_pmc8(port, "ESGp0!")
    if err:
        log("Phase 6", f"WARNING: {err}")
    elif resp and "ESGp" in resp:
        log("Phase 6", f"Propeller responding: {resp.strip()}")
    else:
        log("Phase 6", f"Propeller not responding cleanly (got: {resp!r})")
        log("Phase 6", "The normal PMC8 firmware may not be loaded correctly.")

    log("Phase 6", "Querying Propeller firmware version (ESGv!)...")
    resp, err = query_pmc8(port, "ESGv!")
    if err:
        log("Phase 6", f"WARNING: {err}")
    elif resp and "ESGv" in resp:
        log("Phase 6", f"Propeller firmware: {resp.strip()}")
    else:
        log("Phase 6", f"No version response (got: {resp!r})")

    # ── ESP32 firmware check (pass-through AT+GMR) ───────────────────────
    log("Phase 6", "Re-entering pass-through to read ESP32 firmware version...")
    new_ver, new_mod, raw_gmr = read_esp_version_via_passthrough(port, "Phase 6")

    expected_ver = version  # from Phase 1 binary scan
    expected_mod = module

    def _label(v, m):
        if not v:
            return "(not available)"
        return f"{v}({m})" if m else v

    print()
    print(f"  Expected (from binary)  : {_label(expected_ver, expected_mod)}")
    print(f"  Before the update       : {_label(old_esp_version, old_esp_module)}")
    print(f"  Now installed (AT+GMR)  : {_label(new_ver, new_mod)}")
    print()

    result = None
    if new_ver is None:
        result = "UNKNOWN"
        log("Phase 6", f"Could not read the new ESP32 version. Raw AT+GMR: {raw_gmr!r}")
        log("Phase 6", "The ESP32 may still be booting, or may not have reset after")
        log("Phase 6", "the Propeller firmware load. Power-cycle the mount and retry")
        log("Phase 6", "verification manually (UFCT -> Get Configuration -> check")
        log("Phase 6", "modem type in top right).")
    elif expected_ver and normalize_version(new_ver) == normalize_version(expected_ver):
        result = "SUCCESS"
    elif old_esp_version and normalize_version(new_ver) == normalize_version(old_esp_version):
        result = "FAILED (unchanged)"
        log("Phase 6", f"The ESP32 is still running the OLD firmware ({new_ver}).")
        log("Phase 6", "The update did NOT take effect. Likely causes:")
        log("Phase 6", "  - The boot jumper wasn't firmly seated during Phase 4.")
        log("Phase 6", "  - esptool reported a failure that went unnoticed.")
        log("Phase 6", "Try re-running the procedure from the start.")
    else:
        result = "UNEXPECTED"
        log("Phase 6", f"ESP32 reports {new_ver} but binary expected {expected_ver}.")
        log("Phase 6", "Partial flash, wrong binary, or the version string in the")
        log("Phase 6", "binary didn't match what AT+GMR reports. Investigate.")

    print()
    banner(f"SERIAL FLASH UPDATE COMPLETE -- {result}")
    print()

    if result != "SUCCESS":
        print("You can also open UFCT, click 'Get Configuration', and check the")
        print("MODEM TYPE displayed in the TOP RIGHT as a cross-check.")
        print()
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[Aborted by user]")
        sys.exit(1)
